from bs4 import BeautifulSoup
import csv


def parse_html(html):
    soup = BeautifulSoup(html, 'html.parser')
    ul = soup.select('.news_list')[0]
    li_list = ul.find_all('li')
    news_list = []
    for li in li_list:
        news = li.find('a')
        news_link = news.get('href')
        news_name = news.get_text()
        span_list = li.find_all('span')
        news_writer = span_list[0].get_text()
        news_time = span_list[1].get_text()
        news_image = li.find('img').get('src')
        news_item = [news_link, news_name,
                     news_writer, news_time, news_image]
        news_list.append(news_item)
    return news_list


def save_csv(data_list):
    # 【提示1】定义title表头信息

    # 【提示2】使用open()打开csv文件

    # 【提示3】使用csv模块的writer功能创建csv文件对象

    # 【提示4】使用csv模块的writerow功能写入表头信息title

    # 【提示5】使用csv模块的writerows功能写入data_list数据

    # 【提示6】关闭文件



# 读取文件操作
# 文件操作三大步：①打开文件②读取文件内容③关闭文件
f = open('sports.txt', 'r', encoding='UTF-8')
html = f.read()
f.close()
data_list = parse_html(html)
save_csv(data_list)
