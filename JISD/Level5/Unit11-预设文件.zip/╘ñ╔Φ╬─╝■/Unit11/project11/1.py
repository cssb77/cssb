from bs4 import BeautifulSoup
# 导入csv模块


# 封装parse_html函数
def parse_html(html):
    soup = BeautifulSoup(html, 'html.parser')
    ul = soup.select('.news_list')[0]
    li_list = ul.find_all('li')
    # 定义news_list空列表

    for li in li_list:
        news_image = li.find('img')
        news_image_link = news_image.get('src')
        news = li.find('a')
        news_link = news.get('href')
        news_name = news.get_text()
        span_list = li.find_all('span')
        news_writer = span_list[0].get_text()
        news_time = span_list[1].get_text()
        news_item = [news_name, news_writer,
                     news_time, news_link, news_image_link]
        # 使用append功能将news_item增加到news_list列表中

    # 使用return语句返回news_list


# 读取文件
f = open('science.txt', 'r', encoding='UTF-8')
html = f.read()
f.close()
data_list = parse_html(html)
# 定义title表头。

# open()打开csv文件对象。

# 使用writer()功能创建csv文件writer对象。

# 使用writerow()功能写入表头title数据。

# 使用writerows()功能写入data_list数据。

# close()关闭文件
