info = [['小明', '男', 13], ['小红', '女', 11], ['小强', '男', 12]]
name = ['小猿', '男', 4]
# 使用append()将name添加到info中

print(info)
