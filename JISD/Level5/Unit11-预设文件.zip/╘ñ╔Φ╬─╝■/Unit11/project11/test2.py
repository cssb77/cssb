data_list = [1, 2, 3, 4]
print(type(data_list))


new_data_list = str(data_list)
print(type(new_data_list))
# print(new_data_list)