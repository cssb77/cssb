import requests
from bs4 import BeautifulSoup


def get_html_text(url):
    r = requests.get(url)
    if r.status_code == 200:
        r.encoding = 'UTF-8'
        return r.text
    else:
        return '爬取失败！'


science_url = 'https://show.ybccode.com/news_l5/military/'
html = get_html_text(science_url)
# 【提示1】使用BeautifulSoup功能和内置解析器 html.parser 对HTML代码进行解析格式化

# 【提示2】使用find功能查找class属性为center_bottom的div标签

# 【提示3】使用find功能查找新闻标题所在的a标签

# 【提示4】使用get_text功能获取文本内容并打印
