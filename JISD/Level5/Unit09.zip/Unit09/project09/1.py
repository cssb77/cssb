import requests
from bs4 import BeautifulSoup


def get_html_text(url):
    r = requests.get(url)
    if r.status_code == 200:
        r.encoding = 'UTF-8'
        return r.text
    else:
        return '爬取失败！'


url = 'https://show.ybccode.com/news_l5/science/'
html = get_html_text(url)
# 使用BeautifulSoup功能，利用'html.parser'解析器解析html


# 获取一个标签对象



