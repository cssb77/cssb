import requests
from bs4 import BeautifulSoup


def get_html_text(url):
    r = requests.get(url)
    if r.status_code == 200:
        r.encoding = 'UTF-8'
        return r.text
    else:
        return '爬取失败！'


url = 'https://show.ybccode.com/news_l5/science/'
html = get_html_text(url)
# 使用BeautifulSoup功能，利用'html.parser'解析器解析html
soup = BeautifulSoup(html, 'html.parser')
# 使用find功能查找title标签


# 使用find功能，查找div标签


# 使用find功能的attrs可选参数，查找class属性为center_bottom的div标签


# 查找该div标签中的a标签，并使用get_text()功能获取其文本内容


# 【拓展知识】直接对该div使用get_text()功能获取其文本内容
